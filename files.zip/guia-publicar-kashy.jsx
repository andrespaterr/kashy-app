import { useState } from "react";

const steps = [
  {
    number: 1,
    title: "Descarga el proyecto",
    icon: "📦",
    content: "Descarga el archivo kashy-proyecto.zip que te dejé arriba. Es el proyecto completo listo para publicar.",
    tip: "Guárdalo en una carpeta fácil de encontrar, como el Escritorio.",
    action: null,
  },
  {
    number: 2,
    title: "Crea una cuenta en Netlify",
    icon: "🌐",
    content: "Netlify es un servicio gratuito que pone tu app en internet. Ve a netlify.com y regístrate. Puedes usar tu cuenta de Google o email.",
    tip: "Es 100% gratis para proyectos como este. No pide tarjeta de crédito.",
    action: { label: "Ir a Netlify →", url: "https://app.netlify.com/signup" },
  },
  {
    number: 3,
    title: "Conecta con GitHub (recomendado)",
    icon: "🔗",
    content: "La forma más fácil es subir el código a GitHub primero y conectarlo con Netlify. Así cada cambio se publica automáticamente.",
    substeps: [
      "Ve a github.com y crea una cuenta si no tienes (es gratis)",
      "Crea un nuevo repositorio: haz clic en '+' → 'New repository'",
      "Nómbralo 'kashy-app' y déjalo público",
      "Sube los archivos del ZIP descomprimido al repositorio",
    ],
    tip: "Si esto te parece complicado, hay una opción más fácil en el paso alternativo abajo.",
    action: { label: "Ir a GitHub →", url: "https://github.com/new" },
  },
  {
    number: "3B",
    title: "Alternativa: Sube directo sin GitHub",
    icon: "⚡",
    content: "Si GitHub te parece mucho, Netlify te deja subir archivos directamente arrastrando una carpeta. Pero primero necesitas compilar el proyecto.",
    substeps: [
      "Instala Node.js desde nodejs.org (descarga la versión LTS)",
      "Descomprime el ZIP de kashy-proyecto",
      "Abre la terminal/CMD en esa carpeta",
      "Escribe: npm install (espera a que termine)",
      "Escribe: npm run build (esto crea la carpeta 'build')",
      "En Netlify, ve a Sites → arrastra la carpeta 'build' completa",
    ],
    tip: "Si nunca has usado terminal, el paso 3 con GitHub es más visual y amigable.",
    action: { label: "Descargar Node.js →", url: "https://nodejs.org" },
  },
  {
    number: 4,
    title: "Conecta GitHub con Netlify",
    icon: "🚀",
    content: "Si elegiste el paso 3 con GitHub:",
    substeps: [
      "En Netlify, haz clic en 'Add new site' → 'Import an existing project'",
      "Elige 'GitHub' y autoriza el acceso",
      "Selecciona tu repositorio 'kashy-app'",
      "En Build command escribe: npm run build",
      "En Publish directory escribe: build",
      "Haz clic en 'Deploy site'",
    ],
    tip: "Netlify tarda 1-3 minutos en compilar y publicar. Cuando termine, te da un link tipo random-name.netlify.app",
  },
  {
    number: 5,
    title: "Personaliza tu URL",
    icon: "✨",
    content: "Netlify te asigna un nombre aleatorio. Cámbialo a algo memorable:",
    substeps: [
      "Ve a Site settings → Domain management",
      "Haz clic en 'Options' → 'Edit site name'",
      "Escribe: kashy-app (o el nombre que quieras)",
      "Tu app quedará en: kashy-app.netlify.app",
    ],
    tip: "Este es el link que vas a compartir por WhatsApp. Hazlo corto y fácil de recordar.",
  },
  {
    number: 6,
    title: "¡Comparte con tus beta testers!",
    icon: "🎉",
    content: "Ya tienes Kashy en internet. Ahora comparte el link con las personas que quieras que la prueben.",
    substeps: [
      "Manda el link por WhatsApp a 10-15 personas de confianza",
      "Diles: 'Estoy creando una app de finanzas para parejas. ¿La pruebas y me dices qué tal?'",
      "Pídeles que la abran desde el celular (está optimizada para móvil)",
      "Después de 1 semana, pregúntales: ¿Qué te gustó? ¿Qué le falta? ¿Pagarías por esto?",
    ],
    tip: "El feedback honesto de gente real vale más que 100 features nuevas. Escucha TODO lo que te digan.",
  },
];

export default function GuiaDespliegue() {
  const [openStep, setOpenStep] = useState(1);

  return (
    <div style={{
      minHeight: "100vh",
      background: "#F5F6FA",
      fontFamily: "'Nunito', 'Segoe UI', sans-serif",
      padding: "0 0 40px",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet" />

      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #6C5CE7, #A29BFE)",
        padding: "28px 20px 24px",
        color: "#fff",
        textAlign: "center",
      }}>
        <p style={{ fontSize: 28, fontWeight: 800, margin: "0 0 4px" }}>🚀 Publicar Kashy</p>
        <p style={{ fontSize: 14, opacity: 0.85, margin: 0 }}>Guía paso a paso para poner tu app en internet</p>
        <p style={{ fontSize: 11, opacity: 0.6, margin: "8px 0 0" }}>Tiempo estimado: 20-30 minutos · Costo: $0</p>
      </div>

      <div style={{ maxWidth: 500, margin: "0 auto", padding: "16px" }}>
        {/* Overview */}
        <div style={{
          background: "#fff",
          borderRadius: 16,
          padding: "16px",
          marginBottom: 16,
          border: "1px solid #EEEFF3",
        }}>
          <p style={{ fontSize: 13, fontWeight: 700, color: "#1A1A2E", margin: "0 0 8px" }}>📋 Resumen rápido</p>
          <p style={{ fontSize: 12, color: "#666", lineHeight: 1.6, margin: 0 }}>
            Vamos a tomar el código de Kashy, subirlo a internet usando servicios gratuitos, y obtener un link que cualquier persona puede abrir desde su celular. No necesitas pagar hosting, dominio, ni nada.
          </p>
        </div>

        {/* Steps */}
        {steps.map((step) => {
          const isOpen = openStep === step.number;
          return (
            <div
              key={step.number}
              style={{
                background: "#fff",
                borderRadius: 16,
                marginBottom: 10,
                border: isOpen ? "2px solid #6C5CE7" : "1px solid #EEEFF3",
                overflow: "hidden",
                transition: "all 0.2s ease",
              }}
            >
              <button
                onClick={() => setOpenStep(isOpen ? null : step.number)}
                style={{
                  width: "100%",
                  padding: "14px 16px",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  textAlign: "left",
                }}
              >
                <div style={{
                  width: 36, height: 36, borderRadius: 10,
                  background: isOpen ? "#6C5CE7" : "#F5F6FA",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 18, flexShrink: 0,
                  transition: "background 0.2s",
                }}>
                  {isOpen ? <span style={{ color: "#fff", fontSize: 14, fontWeight: 800 }}>{step.number}</span> : step.icon}
                </div>
                <div style={{ flex: 1 }}>
                  <p style={{
                    fontSize: 14, fontWeight: 700, margin: 0,
                    color: isOpen ? "#6C5CE7" : "#1A1A2E",
                    fontFamily: "'Nunito', sans-serif",
                  }}>
                    {step.number === "3B" ? "↳ " : `Paso ${step.number}: `}{step.title}
                  </p>
                </div>
                <span style={{ fontSize: 16, color: "#ccc", transform: isOpen ? "rotate(180deg)" : "none", transition: "transform 0.2s" }}>▾</span>
              </button>

              {isOpen && (
                <div style={{ padding: "0 16px 16px", animation: "fadeIn 0.2s ease" }}>
                  <p style={{ fontSize: 13, color: "#555", lineHeight: 1.7, margin: "0 0 10px" }}>
                    {step.content}
                  </p>

                  {step.substeps && (
                    <div style={{ margin: "0 0 10px" }}>
                      {step.substeps.map((sub, i) => (
                        <div key={i} style={{
                          display: "flex", gap: 8, alignItems: "flex-start",
                          padding: "6px 0",
                        }}>
                          <div style={{
                            width: 22, height: 22, borderRadius: "50%",
                            background: "#6C5CE715", color: "#6C5CE7",
                            display: "flex", alignItems: "center", justifyContent: "center",
                            fontSize: 11, fontWeight: 800, flexShrink: 0, marginTop: 1,
                          }}>
                            {i + 1}
                          </div>
                          <p style={{ fontSize: 12, color: "#444", margin: 0, lineHeight: 1.5 }}>{sub}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {step.tip && (
                    <div style={{
                      padding: "10px 12px", borderRadius: 10,
                      background: "#FFF9DB", border: "1px solid #FFE8A3",
                      marginBottom: step.action ? 10 : 0,
                    }}>
                      <p style={{ fontSize: 11, color: "#8B6914", margin: 0, lineHeight: 1.5 }}>
                        💡 <strong>Tip:</strong> {step.tip}
                      </p>
                    </div>
                  )}

                  {step.action && (
                    <a
                      href={step.action.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        display: "inline-block",
                        padding: "10px 20px",
                        borderRadius: 10,
                        background: "linear-gradient(135deg, #6C5CE7, #A29BFE)",
                        color: "#fff",
                        fontSize: 13,
                        fontWeight: 700,
                        textDecoration: "none",
                        fontFamily: "'Nunito', sans-serif",
                      }}
                    >
                      {step.action.label}
                    </a>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {/* Help note */}
        <div style={{
          background: "linear-gradient(135deg, #6C5CE710, #A29BFE10)",
          borderRadius: 16,
          padding: "18px",
          border: "1px solid #6C5CE722",
          marginTop: 6,
          textAlign: "center",
        }}>
          <p style={{ fontSize: 14, fontWeight: 700, color: "#6C5CE7", margin: "0 0 6px" }}>
            ¿Te trabaste en algún paso?
          </p>
          <p style={{ fontSize: 12, color: "#666", margin: 0, lineHeight: 1.6 }}>
            Vuelve a esta conversación y dime en cuál paso estás. Te ayudo a resolverlo. No hay pregunta tonta — para eso estoy.
          </p>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn { from { opacity: 0 } to { opacity: 1 } }
        * { box-sizing: border-box; }
      `}</style>
    </div>
  );
}
